CREATE TABLE IF NOT EXISTS city_index (
  city TEXT, state TEXT, restaurant_count INTEGER, grade_a INTEGER,
  grade_f INTEGER, avg_score REAL, south REAL, north REAL, west REAL,
  east REAL, latest_inspection TEXT
);
CREATE TABLE IF NOT EXISTS city_index_meta (
  id INTEGER PRIMARY KEY, total INTEGER, built_at TEXT
);
DELETE FROM city_index;
INSERT INTO city_index SELECT city, state, COUNT(*), SUM(vetted_grade = 'A'),
  SUM(vetted_grade = 'F'), ROUND(AVG(weighted_score), 1), MIN(lat), MAX(lat),
  MIN(lng), MAX(lng), MAX(inspection_date)
  FROM restaurants WHERE lat IS NOT NULL GROUP BY city, state
  HAVING COUNT(*) >= 25;
INSERT OR REPLACE INTO city_index_meta (id, total, built_at)
  SELECT 1, COUNT(*), datetime('now') FROM restaurants;
