-- Public wording for two summary phrases (dinescores_pipeline.SUMMARY_DISPLAY_NAMES):
-- "Live roaches found" -> "Roaches found" (it was shown for dead roaches too) and
-- "Rodent activity detected" -> "Rodents or droppings found". Rewrites only the
-- "text" field of stored summaries, and only on rows that carry the old phrase.
-- Idempotent; new rows are written with the new wording by the pipeline.
UPDATE restaurants SET summaries = replace(replace(summaries,
  '"text":"Live roaches found"', '"text":"Roaches found"'),
  '"text": "Live roaches found"', '"text": "Roaches found"')
  WHERE summaries LIKE '%"Live roaches found"%';
UPDATE restaurants SET summaries = replace(replace(summaries,
  '"text":"Rodent activity detected"', '"text":"Rodents or droppings found"'),
  '"text": "Rodent activity detected"', '"text": "Rodents or droppings found"')
  WHERE summaries LIKE '%"Rodent activity detected"%';
